/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.misiontic.proyectofarmacia;

import javax.swing.JFrame;

/**
 *
 * @author jorge
 */
public class VistaManual extends JFrame  {
    
    
    public VistaManual() { //Constructor de la clase Datos
        
}
    
    
}
